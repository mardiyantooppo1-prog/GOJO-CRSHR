package com.gojolenzx.crosshair;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;

public class OverlayService extends Service {
    public static final String EXTRA_SIZE = "crosshair_size";
    public static final String ACTION_STOP = "com.gojolenzx.crosshair.STOP";
    private static final String CHANNEL_ID = "gojo_crosshair_channel";
    private WindowManager windowManager;
    private CrosshairView crosshairView;
    private WindowManager.LayoutParams overlayParams;
    private int size = 30;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(101, buildNotification());
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (intent != null) size = intent.getIntExtra(EXTRA_SIZE, size);
        if (crosshairView != null) {
            crosshairView.setSize(size);
            crosshairView.invalidate();
            return START_STICKY;
        }
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        overlayParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        overlayParams.gravity = Gravity.CENTER;
        crosshairView = new CrosshairView();
        try {
            windowManager.addView(crosshairView, overlayParams);
        } catch (Exception e) {
            stopSelf();
        }
        return START_STICKY;
    }

    private Notification buildNotification() {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pending = PendingIntent.getActivity(
                this, 0, open,
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                        ? PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT
                        : PendingIntent.FLAG_UPDATE_CURRENT);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            return new Notification.Builder(this, CHANNEL_ID)
                    .setContentTitle("Gojo Lenxz aktif")
                    .setContentText("Crosshair overlay sedang berjalan")
                    .setSmallIcon(android.R.drawable.ic_menu_compass)
                    .setContentIntent(pending)
                    .setOngoing(true)
                    .build();
        }
        return new Notification.Builder(this)
                .setContentTitle("Gojo Lenxz aktif")
                .setContentText("Crosshair overlay sedang berjalan")
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .setContentIntent(pending)
                .setOngoing(true)
                .build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "Gojo Lenxz Crosshair", NotificationManager.IMPORTANCE_LOW);
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    @Override
    public void onDestroy() {
        if (crosshairView != null && windowManager != null) {
            try { windowManager.removeView(crosshairView); } catch (Exception ignored) {}
            crosshairView = null;
        }
        stopForeground(true);
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    private class CrosshairView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private int crosshairSize;
        private float downX, downY;
        private int startX, startY;

        CrosshairView() {
            super(OverlayService.this);
            setSize(size);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }

        void setSize(int newSize) { crosshairSize = Math.max(10, Math.min(50, newSize)); }

        @Override
        protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
            int d = (int) (crosshairSize * getResources().getDisplayMetrics().density);
            int total = d + (int) (24 * getResources().getDisplayMetrics().density);
            setMeasuredDimension(total, total);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float density = getResources().getDisplayMetrics().density;
            float cX = getWidth() / 2f;
            float cY = getHeight() / 2f;
            float r = crosshairSize * density / 2f;
            paint.setColor(Color.rgb(45, 220, 255));
            paint.setStrokeWidth(2.2f * density);
            paint.setStyle(Paint.Style.STROKE);
            paint.setShadowLayer(7f * density, 0, 0, Color.BLUE);
            float gap = 4f * density;
            float arm = Math.max(6f * density, r * 0.55f);
            canvas.drawLine(cX - gap - arm, cY, cX - gap, cY, paint);
            canvas.drawLine(cX + gap, cY, cX + gap + arm, cY, paint);
            canvas.drawLine(cX, cY - gap - arm, cX, cY - gap, paint);
            canvas.drawLine(cX, cY + gap, cX, cY + gap + arm, paint);
            canvas.drawCircle(cX, cY, 2f * density, paint);
            paint.clearShadowLayer();
            paint.setStyle(Paint.Style.FILL);
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    downX = event.getRawX();
                    downY = event.getRawY();
                    startX = overlayParams.x;
                    startY = overlayParams.y;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    overlayParams.x = startX + (int) (event.getRawX() - downX);
                    overlayParams.y = startY + (int) (event.getRawY() - downY);
                    try { windowManager.updateViewLayout(this, overlayParams); } catch (Exception ignored) {}
                    return true;
            }
            return true;
        }
    }
}
