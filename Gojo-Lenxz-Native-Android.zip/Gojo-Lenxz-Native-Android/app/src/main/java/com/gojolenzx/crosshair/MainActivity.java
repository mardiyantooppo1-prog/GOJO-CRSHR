package com.gojolenzx.crosshair;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private int crosshairSize = 30;
    private TextView sizeLabel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(28), dp(24), dp(24));
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(Color.rgb(5, 10, 28));

        TextView title = new TextView(this);
        title.setText("GOJO LENXZ");
        title.setTextColor(Color.rgb(70, 220, 255));
        title.setTextSize(30);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, 1);
        root.addView(title, matchWrap());

        TextView subtitle = new TextView(this);
        subtitle.setText("CROSSHAIR OVERLAY");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setTextSize(13);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subParams = matchWrap();
        subParams.topMargin = dp(8);
        root.addView(subtitle, subParams);

        TextView info = new TextView(this);
        info.setText("Pilih ukuran bidik, lalu aktifkan overlay. Aplikasi ini hanya menampilkan crosshair di layar; tidak mengubah file game atau memberi auto-aim.");
        info.setTextColor(Color.WHITE);
        info.setTextSize(15);
        info.setGravity(Gravity.CENTER);
        info.setPadding(0, dp(26), 0, dp(24));
        root.addView(info, matchWrap());

        sizeLabel = new TextView(this);
        sizeLabel.setText("Ukuran crosshair: " + crosshairSize);
        sizeLabel.setTextColor(Color.rgb(70, 220, 255));
        sizeLabel.setTextSize(16);
        root.addView(sizeLabel, matchWrap());

        SeekBar seek = new SeekBar(this);
        seek.setMax(40);
        seek.setProgress(20);
        LinearLayout.LayoutParams seekParams = matchWrap();
        seekParams.bottomMargin = dp(22);
        root.addView(seek, seekParams);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                crosshairSize = 10 + progress;
                sizeLabel.setText("Ukuran crosshair: " + crosshairSize);
            }
            @Override public void onStartTrackingTouch(SeekBar bar) {}
            @Override public void onStopTrackingTouch(SeekBar bar) {}
        });

        Button start = new Button(this);
        start.setText("AKTIFKAN CROSSHAIR");
        start.setAllCaps(false);
        root.addView(start, matchWrap());
        start.setOnClickListener(v -> startOverlay());

        Button stop = new Button(this);
        stop.setText("MATIKAN CROSSHAIR");
        stop.setAllCaps(false);
        LinearLayout.LayoutParams stopParams = matchWrap();
        stopParams.topMargin = dp(12);
        root.addView(stop, stopParams);
        stop.setOnClickListener(v -> {
            Intent intent = new Intent(this, OverlayService.class);
            intent.setAction(OverlayService.ACTION_STOP);
            startServiceCompat(intent);
            Toast.makeText(this, "Perintah mematikan crosshair dikirim", Toast.LENGTH_SHORT).show();
        });

        TextView foot = new TextView(this);
        foot.setText("Catatan: Android akan meminta izin 'Tampilkan di atas aplikasi lain'.");
        foot.setTextColor(Color.GRAY);
        foot.setTextSize(12);
        foot.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams footParams = matchWrap();
        footParams.topMargin = dp(24);
        root.addView(foot, footParams);

        setContentView(root);
    }

    private void startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            Intent permission = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(permission);
            Toast.makeText(this, "Izinkan 'Tampilkan di atas aplikasi lain', lalu kembali dan tekan Aktifkan.", Toast.LENGTH_LONG).show();
            return;
        }
        Intent intent = new Intent(this, OverlayService.class);
        intent.putExtra(OverlayService.EXTRA_SIZE, crosshairSize);
        startServiceCompat(intent);
        Toast.makeText(this, "Crosshair diaktifkan", Toast.LENGTH_SHORT).show();
    }

    private void startServiceCompat(Intent intent) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent);
        } else {
            startService(intent);
        }
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
